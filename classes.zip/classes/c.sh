cp GeoSDoub.class ../$1/GeoSDoub.class
